# PayPanel - build the .jar with GitHub (no installs)

You need: a free GitHub account, a PC or phone browser, 10 minutes.

1. UNZIP paypanel.zip on your device (GitHub can't read zips).
   You should see: src, build.gradle, gradle.properties, settings.gradle, .gitignore, .github

2. Go to github.com, sign up / log in.

3. Click the + (top right) -> "New repository".
   Name: paypanel   -> Public -> "Create repository".

4. On the empty repo page click "uploading an existing file".
   Drag in: the `src` FOLDER, build.gradle, gradle.properties,
   settings.gradle, .gitignore. Wait for the upload bar, then click
   "Commit changes". (Don't worry if the .github folder is missing, next step.)

5. Add the build script: click "Add file" -> "Create new file".
   In the name box type exactly:   .github/workflows/build.yml
   (typing the / makes the folders). Paste the contents of the
   build.yml file from the zip into the big box. Click "Commit changes" ->
   "Commit changes" again.

6. Click the "Actions" tab. If asked, click "I understand my workflows, enable them".
   You'll see "Build mod" running (yellow circle). Wait 3-6 minutes
   until it turns into a green check.
   Red X? Click it, copy the red error text and send it to me.

7. Click the finished run, scroll to "Artifacts" at the bottom,
   click "paypanel-mod". A zip downloads. Unzip it: inside is paypanel-1.0.0.jar.

8. Put that .jar into .minecraft/mods, together with the Fabric API
   jar for 1.21.11 (modrinth.com/mod/fabric-api), using a Fabric 1.21.11 profile.

Settings file after first launch: .minecraft/config/paypanel.json
(chat-line pattern, commands, double-click safety, max payout).
